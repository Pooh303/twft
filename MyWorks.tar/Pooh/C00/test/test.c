#include "ft_putchar.c"
#include "ft_print_alphabet.c"
#include "ft_print_reverse_alphabet.c"
#include "ft_print_numbers.c"
#include "ft_is_negative.c"

int	main(void)
{
	ft_putchar('a');
	ft_print_alphabet();
	ft_print_reverse_alphabet();
	ft_print_numbers();
	ft_is_negative(-1);
}
