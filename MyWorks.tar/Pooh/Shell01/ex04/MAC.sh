ifconfig | awk '/ether/ && !/autoselect/ {print $2}'
