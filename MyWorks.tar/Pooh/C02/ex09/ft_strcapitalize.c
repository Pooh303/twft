/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: phsripha <phsripha@student.42bangkok.com>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/29 21:04:29 by phsripha          #+#    #+#             */
/*   Updated: 2023/11/29 21:04:31 by phsripha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcapitalize(char *str)
{
	int	next;

	next = 1;
	while (*str)
	{
		if (*str < '0' || (*str > '9' && *str < 'A') || \
		(*str > 'Z' && *str < 'a') || *str > 122)
		{
			next = 1;
		}
		else if (next && (*str >= 'a' && *str <= 'z'))
		{
			*str = *str - ('a' - 'A');
			next = 0;
		}
		else if (*str >= 'A' && *str <= 'Z')
		{
			*str = *str - ('A' - 'a');
		}
		str++;
	}
	return (str);
}
