/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: phsripha <phsripha@student.42bangkok.com>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/28 22:08:06 by phsripha          #+#    #+#             */
/*   Updated: 2023/11/28 22:08:35 by phsripha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_printable(char *str)
{
	while (*str)
	{
		if (*str < 32 || *str > 126)
		{
			return (0);
		}
		str++;
	}
	return (1);
}

/*int	main(void)
{
	char	nonprintable[20];
	char	printable[20];

	nonprintable[20] = "Hello, \nWorld!";
	printable[20] = "Hello, World!";
	printf("%d\n", ft_str_is_printable(nonprintable));
	printf("%d", ft_str_is_printable(printable));
	return (0);
}*/
