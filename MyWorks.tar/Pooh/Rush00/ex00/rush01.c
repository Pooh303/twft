/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush01.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pklangpe <pklangpe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/25 14:07:56 by pklangpe          #+#    #+#             */
/*   Updated: 2023/11/26 17:11:18 by rfatkiev         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		rush_guard(int x, int y);

void	ft_print_line(int size, char end_a, char end_b, char line_char);

void	rush(int x_size, int y_size)
{
	int	itr_y;

	if (rush_guard(x_size, y_size) == 0)
		return ;
	ft_print_line(x_size, '/', '\\', '*');
	itr_y = y_size - 2;
	while (itr_y > 0)
	{
		ft_print_line(x_size, '*', '*', ' ');
		itr_y--;
	}
	if (itr_y > -1)
		ft_print_line(x_size, '\\', '/', '*');
}
/*
int main(int argc, char **argv)
{
	printf("Testing: 5,5\n");
	rush01(5, 5);
	printf("Testing: 5,1\n");
	rush01(5, 1);
	printf("Testing: 1,1\n");
	rush01(1, 1);
	printf("Testing: 1,5\n");
	rush01(1, 5);
	printf("Testing: 5,null\n");
	rush01(5,'\0'); //guard works
}
//*/
