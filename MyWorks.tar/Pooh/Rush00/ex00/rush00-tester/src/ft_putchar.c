/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putchar.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rfatkiev <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/24 21:18:31 by rfatkiev          #+#    #+#             */
/*   Updated: 2023/11/26 17:23:07 by rfatkiev         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush.h"

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *str)
{
	while (*str != '\0')
	{
		ft_putchar(*str);
		str++;
	}
}

//Checks if the value is valid enough to print.
//e.g. not null, pointer, or nullpointer.
int	rush_guard(int x, int y)
{
	if (!x || !y || x == (int) NULL || y == (int) NULL)
	{
		ft_putstr("Error: x or y must be an integer value > 0.\n");
		return (0);
	}
	else if (x < 0 || y < 0)
	{
		ft_putstr("Error: x and/or y is < 0. Must be int value > 0.\n");
		return (0);
	}
	return (1);
}

void	ft_print_line(int size, char end_a, char end_b, char line_char)
{
	size = size - 2;
	ft_putchar(end_a);
	while (size > 0)
	{
		ft_putchar(line_char);
		size--;
	}
	if (size > -1)
		ft_putchar(end_b);
	ft_putchar('\n');
}

/*
void	ft_print_line_v(int size, char end, char line_char)
{
	ft_print_line(size, end, end, line_char);
}
*/

int	ft_strtoint(const char *str)
{
	int	result;

	result = 0;
	while (*str >= '0' && *str <= '9')
	{
		result = result * 10 + (*str - '0');
		str++;
	}
	return (result);
}
