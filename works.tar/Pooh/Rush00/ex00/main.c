/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rfatkiev <rfatkiev@student.42bangkok.com>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/24 21:20:56 by rfatkiev          #+#    #+#             */
/*   Updated: 2023/11/26 17:23:30 by rfatkiev         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putstr(char *str);

void	rush(int x_size, int y_size);

int		ft_strtoint(const char *str);

void	test_functions(void)
{
	ft_putstr("=====TESTING: rush=====\n");
	ft_putstr("\nTesting: 5,3\n");
	rush(5, 3);
	ft_putstr("\nTesting: 5,1\n");
	rush(5, 1);
	ft_putstr("\nTesting: 1,1\n");
	rush(1, 1);
	ft_putstr("\nTesting: 1,5\n");
	rush(1, 5);
	ft_putstr("\nTesting: 4,4\n");
	rush(4, 4);
	ft_putstr("\nTesting: 4,0\n");
	rush(4, 0);
	ft_putstr("\nTesting: 0,4\n");
	rush(0, 4);
	ft_putstr("\nTesting: 0,0\n");
	rush(0, 0);
	ft_putstr("\nTesting: -5,-5\n");
	rush(-5, -5);
}

int	main(int argc, char *argv[])
{
	if (argc > 2)
		rush(ft_strtoint(argv[1]), ft_strtoint(argv[2]));
	else
	{
		// ft_putstr("Empty or < 2 argument, using default value 5, 5.\n");
		rush(5, 5);
	}
	return (0);
}
