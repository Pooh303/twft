/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rfatkiev <rfatkiev@student.42bangkok.com>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/24 21:20:56 by rfatkiev          #+#    #+#             */
/*   Updated: 2023/11/25 18:54:06 by rfatkiev         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putstr(char *str);

void	rush03(int x_size, int y_size);
// void	rush00(int x_size, int y_size);
// void	rush01(int x_size, int y_size);
// void	rush02(int x_size, int y_size);
// void	rush04(int x_size, int y_size);

void	test_functions(int num)
{
	if (num == 03)
	{
		ft_putstr("=====TESTING: rush03=====\n");
		ft_putstr("\nTesting: 5,3\n");
		rush03(5, 3);
		ft_putstr("\nTesting: 5,1\n");
		rush03(5, 1);
		ft_putstr("\nTesting: 1,1\n");
		rush03(1, 1);
		ft_putstr("\nTesting: 1,5\n");
		rush03(1, 5);
		ft_putstr("\nTesting: 4,4\n");
		rush03(4, 4);
		ft_putstr("\nTesting: -5,-5\n");
		rush03(-5, -5);
	}
	else if (num == 00)
	{
		ft_putstr("=====TESTING: rush00=====\n");
		ft_putstr("\nTesting: 5,3\n");
		rush00(5, 3);
		ft_putstr("\nTesting: 5,1\n");
		rush00(5, 1);
		ft_putstr("\nTesting: 1,1\n");
		rush00(1, 1);
		ft_putstr("\nTesting: 1,5\n");
		rush00(1, 5);
		ft_putstr("\nTesting: 4,4\n");
		rush00(4, 4);
		ft_putstr("\nTesting: -5,-5\n");
		rush00(-5, -5);
	}
	else if (num == 01)
	{
		ft_putstr("=====TESTING: rush01=====\n");
		ft_putstr("\nTesting: 5,3\n");
		rush01(5, 3);
		ft_putstr("\nTesting: 5,1\n");
		rush01(5, 1);
		ft_putstr("\nTesting: 1,1\n");
		rush01(1, 1);
		ft_putstr("\nTesting: 1,5\n");
		rush01(1, 5);
		ft_putstr("\nTesting: 4,4\n");
		rush01(4, 4);
		ft_putstr("\nTesting: -5,-5\n");
		rush01(-5, -5);
	}
	else if (num == 02)
	{
		ft_putstr("=====TESTING: rush02=====\n");
		ft_putstr("\nTesting: 5,3\n");
		rush02(5, 3);
		ft_putstr("\nTesting: 5,1\n");
		rush02(5, 1);
		ft_putstr("\nTesting: 1,1\n");
		rush02(1, 1);
		ft_putstr("\nTesting: 1,5\n");
		rush02(1, 5);
		ft_putstr("\nTesting: 4,4\n");
		rush02(4, 4);
		ft_putstr("\nTesting: -5,-5\n");
		rush02(-5, -5);
	}
	else if (num == 04)
	{
		ft_putstr("=====TESTING: rush04=====\n");
		ft_putstr("\nTesting: 5,3\n");
		rush04(5, 3);
		ft_putstr("\nTesting: 5,1\n");
		rush04(5, 1);
		ft_putstr("\nTesting: 1,1\n");
		rush04(1, 1);
		ft_putstr("\nTesting: 1,5\n");
		rush04(1, 5);
		ft_putstr("\nTesting: 4,4\n");
		rush04(4, 4);
		ft_putstr("\nTesting: -5,-5\n");
		rush04(-5, -5);
	}
}

int	main(void)
{
	rush03(5, 5);
	test_functions(00);
	test_functions(01);
	test_functions(02);
	test_functions(03);
	test_functions(04);
	return (0);
}
