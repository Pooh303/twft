/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush03.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rfatkiev <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/24 21:25:05 by rfatkiev          #+#    #+#             */
/*   Updated: 2023/11/26 17:11:59 by rfatkiev         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c);

int		rush_guard(int x, int y);

void	ft_print_line(int size, char end_a, char end_b, char line_char);

void	rush(int x_size, int y_size)
{
	int	vertical_bs;

	if (rush_guard(x_size, y_size) == 0)
		return ;
	ft_print_line(x_size, 'A', 'C', 'B');
	vertical_bs = y_size - 2;
	while (vertical_bs > 0)
	{
		ft_print_line(x_size, 'B', 'B', ' ');
		vertical_bs--;
	}
	if (y_size > 1)
		ft_print_line(x_size, 'A', 'C', 'B');
}
