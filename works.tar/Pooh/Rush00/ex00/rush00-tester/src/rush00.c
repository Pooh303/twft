/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: phsripha <phsripha@student.42bangkok.com>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/26 11:40:01 by phsripha          #+#    #+#             */
/*   Updated: 2023/11/26 17:10:31 by rfatkiev         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush.h"

#include <unistd.h>

int		rush_guard(int x, int y);

void	ft_print_line(int size, char end_a, char end_b, char line_char);

void	rush(int x_size, int y_size)
{
	int	itr_y;

	if (rush_guard(x_size, y_size) == 0)
		return ;
	ft_print_line(x_size, 'o', 'o', '-');
	itr_y = y_size - 2;
	while (itr_y > 0)
	{
		ft_print_line(x_size, '|', '|', ' ');
		itr_y--;
	}
	if (itr_y > -1)
		ft_print_line(x_size, 'o', 'o', '-');
}
