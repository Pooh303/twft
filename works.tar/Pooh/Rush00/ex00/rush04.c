/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush04.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: phsripha <phsripha@student.42bangkok.com>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/26 11:41:31 by phsripha          #+#    #+#             */
/*   Updated: 2023/11/26 11:41:39 by phsripha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	rush_guard(int x, int y);

void	ft_print_line(int size, char end_a, char end_b, char line_char);

void	ft_print_line_v(int size, char end, char line_char);

void	rush04(int x_size, int y_size)
{
	int	itr_y;

	if (rush_guard(x_size, y_size) == 0)
		return ;
	ft_print_line(x_size, 'A', 'C', 'B');
	itr_y = y_size - 2;
	while (itr_y > 0)
	{
		ft_print_line_v(x_size, 'B', ' ');
		itr_y--;
	}
	if (itr_y > -1)
		ft_print_line(x_size, 'C', 'A', 'B');
}
