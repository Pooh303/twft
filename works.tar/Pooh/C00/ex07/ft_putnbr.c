#include <unistd.h>
#include <stdio.h>
#include <string.h>

void	ft_putnbr(int nb);

void	ft_putnbr(int nb = 0)
{	
	sprintf("%d", nb);
}

int main(void)
{
	ft_putnbr(42);
}
