/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: phsripha <phsripha@student.42bangkok.com>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/25 12:10:39 by phsripha          #+#    #+#             */
/*   Updated: 2023/11/25 13:30:03 by phsripha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	rush(int x, int y)
{
	int	tempx;
	int	tempy;
	int	*ptrx;
	int	*ptry;

	tempx = x;
	tempy = y;
	ptrx = &x;
	ptry = &y;
	while (y > 0)
	{
		if (*ptry == tempy || *ptry == 1)
		{
			while (x > 0)
			{
				if (tempx == x || *ptrx == 1)
				{
					printf("o");
				}
				else
				{
					printf("-");
				}
				x--;
			}
		}
		else
		{
			printf("|");
			x--;
			while (x > 1)
			{
				printf(" ");
				x--;
			}
			if (x > 0)
			{
				printf("|");
			}
		}
		x = tempx;
		y--;
		printf("\n");
	}
}