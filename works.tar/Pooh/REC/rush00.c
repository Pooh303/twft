/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: phsripha <phsripha@student.42bangkok.com>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/25 14:14:29 by phsripha          #+#    #+#             */
/*   Updated: 2023/11/25 14:19:44 by phsripha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	vertical_print(int x)
{
	printf("|");
	x--;
	while (x > 1)
	{
		printf(" ");
		x--;
	}
	if (x > 0)
	{
		printf("|");
	}
}

void	horizontal_print(int x, int tempx, int *ptrx)
{
	while (x > 0)
	{
		if (tempx == x || x == 1)
		{
			printf("o");
		}
		else
		{
			printf("-");
		}
		x--;
	}
}

void	rush(int x, int y)
{
	int		tempx;
	int		tempy;
	int		*ptrx;
	int		*ptry;

	tempx = x;
	tempy = y;
	ptrx = &x;
	ptry = &y;
	while (y > 0)
	{
		if (*ptry == tempy || *ptry == 1)
		{
			horizontal_print(x, tempx, ptrx);
		}
		else
		{
			vertical_print(x);
		}
		x = tempx;
		y--;
		printf("\n");
	}
}

int	main(void)
{
	rush(4, 4);
	return (0);
}
