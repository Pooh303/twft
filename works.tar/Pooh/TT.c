/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   TTT.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: phsripha <phsripha@student.42bangkok.com>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/24 14:28:25 by phsripha          #+#    #+#             */
/*   Updated: 2023/11/24 14:43:59 by phsripha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void print(char *str) {
    int count = 0;
    while (*str != '\0') {
        if (count != 0 && count % 5 == 0 && count % 3 == 0) {
            write(1, "5", 1);
        } else if (count != 0 && count % 5 == 0) {
            write(1, "3", 1);
        } else if (count != 0 && count % 3 == 0) {
            write(1, "5", 1);
        } else {
            write(1, str, 1);
        }
        str++;
        count++;
    }
    write(1, "\n", 1);
}

int main(int argc, char *argv[]) {

    char *word = argv[1];
    print(word);

    return 0;
}
