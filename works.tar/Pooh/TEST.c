#include <stdio.h>

// void	ft_ultimate_ft(int *********nbr)
// {
// 	*********nbr = 42;
// }
// void	ft_ft(int *nbr)
// {
// 	*nbr = 42;
// }

// int main(){
//     int a;
//     ft_ft(&a);
//     printf("%d", a);
// }

//  int main(){
//      int n;
//      int *ptr = &n;
//      int **ptr2 = &ptr;
//      int ***ptr3 = &ptr2;
//      int ****ptr4 = &ptr3;
//      int *****ptr5 = &ptr4;
//      int ******ptr6 = &ptr5;
//      int *******ptr7 = &ptr6;
//     int ********ptr8 = &ptr7;
//     int *********ptr9 = &ptr8;
//     ft_ultimate_ft(ptr9);
//     printf("%d\n", n);
//       }

// void	ft_swap(int *a, int *b)
// {
// 	int	temp;

// 	temp = *a;
// 	*a = *b;
// 	*b = temp;
// }

// int main(){
//     int n = 13;
//     int m = 22;
//     int *a = &n;
//     int *b = &m;
//     ft_swap(a, b);
//     printf("%d\n", n);
// }

// void	ft_div_mod(int a, int b, int *div, int *mod)
// {
// 	*div = a / b;
// 	*mod = a % b;
// }

// int main(){
//     int a = 0;
//     int b = 0;
//     int *div = &a;
//     int *mod = &b;
//     ft_div_mod(12, 3, div, mod);
//     printf("%d and %d\n", *div, *mod);
// }


// void	ft_putstr(char *str)
// {
// 	int	count;

// 	count = 0;
// 	while (str[count] != '\0')
// 	{
// 		write(1, &str[count], 1);
// 		++count;
// 	}
// }

// int main(void) {
//     char str1[] = "HelloWorld";
//     ft_putstr(str1);
//     return 0;
// }



// void	ft_ultimate_div_mod(int *a, int *b)
// {
// 	int	temp;

// 	temp = *a;
// 	*a = *a / *b;
// 	*b = temp % *b;
// }

// int main(){
//     int a = 20;
//     int b = 2;
//     int *ptr = &a;
//     int *ptr2 = &b;
    
//     ft_ultimate_div_mod(ptr, ptr2);
//     printf("%d and %d", *ptr, *ptr2);
// }


int	ft_strlen(char *str)
{
	int	count;

	count = 0;
	while (str[count] != '\0')
	{
		count++;
	}
	return count;
}

// int main(){
//     char word[] = "Hi myname is dream";
//     printf("%d", ft_strlen(word));
// }



#include <stdio.h>

void	ft_rev_int_tab(int *tab, int size)
{
	int	*ptr1;
	int	*ptr2;
	int	temp;

	ptr1 = tab;
	ptr2 = tab + size - 1;
	while (ptr1 < ptr2)
	{
	    printf("ptr1 %d\nptr2 %d\n", ptr1, ptr2);
		temp = *ptr1;
		*ptr1 = *ptr2;
		*ptr2 = temp;
		ptr1++;
		ptr2--;
	}
}

// int main() {
//     int arr[] = {87, 65, 4, 2, 4, 10};
//     int size = sizeof(arr) / sizeof(arr[0]);
//     ft_rev_int_tab(arr, size);

//     for (int i = 0; i < size; i++) {
//         if (i < size - 1){
//             printf("%d ", arr[i]);
//         } else if (i <= size){
//             printf("%d", arr[i]);
//         }
//     }
//     return 0;
// }

// void	ft_sort_int_tab(int *tab, int size)
// {
// 	int	i;
// 	int	j;
// 	int	t;

// 	for (i = 0; i < size; i++)
// 	{
// 		for (j = i + 1; j < size; j++)
// 		{
// 			if (*(tab + j) < *(tab + i))
// 			{
// 				t = *(tab + i);
// 				*(tab + i) = *(tab + j);
// 				*(tab + j) = t;
// 			}
// 		}
// 	}
// }

// void	ft_sort_int_tab(int *tab, int size)
// {
// 	int	i;
// 	int	j;
// 	int	temp;

// 	i = 0;
// 	while (i < size)
// 	{
// 		j = i + 1;
// 		while (j < size)
// 		{
// 			if (tab[j] < tab[i])
// 			{
// 				temp = tab[i];
// 				tab[i] = tab[j];
// 				tab[j] = temp;
// 			}
// 			j++;
// 		}
// 		i++;
// 	}
// }



// int main(){
//     int arr[] = {3, -1, 7, 65, 4, 2, 4, 10, 120};
//     int size = sizeof(arr) / sizeof(arr[0]);
//     ft_sort_int_tab(arr, size);
    
//         for (int i = 0; i < size; i++) {
//         if (i < size - 1){
//             printf("%d ", arr[i]);
//         } else if (i <= size){
//             printf("%d", arr[i]);
//         }
//     }
// }


// ==== MAIN FOR C02 ====

#include <stdio.h>

int main(void)
{
    char source[] = "WoW";
    char destination[30]; // Make sure the destination array is large enough

    // Testing ft_strcpy
    ft_strcpy(destination, source);

    // Printing the result
    printf("Source: %s\n", source);
    printf("Destination: %s", destination);

    return 0;
}














